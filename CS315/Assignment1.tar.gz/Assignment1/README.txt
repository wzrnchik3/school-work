Assignment 1: The Secretary
By: Will Zrnchik

Run by using the makefile command: 'make run'
Can also run makefile by using command: 'make', and clean by using 'make clean'

There is a little bit of memory leak that I couldn't figure out. I used delete and that fixed the leak 
but caused other problems.