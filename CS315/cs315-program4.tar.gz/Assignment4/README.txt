Author: 
    William Zrnchik
Contents: 
    test.txt // original txt data given
    main.cpp // main program calls hashtable class
    makefile
    famTree.h // famTree header
    famTree.cpp // famTree cpp
    README.txt // this file
Running:

    To simply run, you can use the makefile by typing "make run" in terminal under the
    correct directory.

    To just compile, type "make" in terminal under the correct directory.

    To clean object files, "make clean" in terminal under the directory.
Implementation Notes:
    Tried to implement BFS for relate and insert and family functions
Limitations: 
    Relate function seg faults
References:
    Blake Yates, friend
    cplusplus.com Doc Pages
    geeksforgeeks.com