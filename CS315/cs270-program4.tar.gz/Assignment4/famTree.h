#include <iostream>
#include <string>
using namespace std;

int const MAX_CHILDREN = 10;
int const MAX_NODE = 100;

struct pnode // person node
{
    int p, m, pid; // parent marraige index and person id
    pnode() // constructor
    {
        p = 0;
        m = 0;
        pid = 0;
    }
};

struct fnode // family node
{
    int h, w, numChildren, fid; // husband or wife index number, number of children, and family ID
    int c[MAX_CHILDREN]; // child nodes max of 10
    fnode() //constructor set all 0
    {
        h = 0;
        w = 0;
        numChildren = 0;
        fid = 0;
        for (int i = 0; i < MAX_CHILDREN; i++)
            c[i] = 0;
    }
};

class famTree
{
    public:
        // famTree(); // constructor
        // ~famTree(); // destructor
        void insert(int personid, int parent, int marriage); // insert function
        void family(int famid, int hid, int wid, int cid[], int numC); // family function
        void check(); // check data for consistency
        void relate(int start, int end); // find shortest path between 2 people
    private:
        fnode fams[MAX_NODE];
        pnode people[MAX_NODE];
};