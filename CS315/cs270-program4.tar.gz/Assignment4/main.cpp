#include "famTree.h"
#include <iostream>
using namespace std;

int main()
{
    famTree f;
    f.insert(1, 1, 2);
    f.insert(2, 3, 2);
    f.check();
    return 0;
}