#include "famTree.h"

// famTree::famTree()
// {
//     for (int i = 0; i < MAX_NODE; i ++)
//         fams[i] = new fnode;
// }

void famTree::insert(int personid, int parent, int marriage)
{
    if (people[personid].m == 0)
        people[personid].m = marriage;
    if (people[personid].p == 0)
        people[personid].p = parent;
    if (people[personid].pid == 0)
        people[personid].pid = personid;
    if (fams[parent].numChildren == 0)
    {
        fams[parent].c[0] = personid;
        fams[parent].numChildren += 1;
    }
    else if (fams[parent].numChildren != 0)
    {
        bool isIn = false;
        for (int i = 0; i < fams[parent].numChildren; i++)
        {
            if (fams[parent].c[i] == personid)
                isIn = true;
        }
        if (isIn == false)
        {
            fams[parent].c[fams[parent].numChildren] = personid;
            fams[parent].numChildren += 1;
        }
    }
    if (fams[marriage].h == 0 && fams[marriage].w == 0)
        fams[marriage].h = personid;
    else
    {
        if (fams[marriage].h == 0 && fams[marriage].w != personid)
            fams[marriage].h = personid;
        else if (fams[marriage].w == 0 && fams[marriage].h != personid)
            fams[marriage].w = personid;
    }
    cout << "Individual " << personid << " has parents " << parent 
        << " and is married in family " << marriage << endl;
}

void famTree::family(int famid, int hid, int wid, int cid[], int numC)
{
    if (fams[famid].h != hid && hid != 0)
    {
        fams[famid].h = hid;
        people[hid].m = famid;
    }
    if (fams[famid].w != wid && wid != 0)
    {
        fams[famid].w = wid;
        people[wid].m = famid;
    }
    for (int i = 0; i < numC; i++)
    {
        fams[famid].c[i] = cid[i];
        people[i].p = famid;
    }
    cout << "Family " << famid << " has husband " << hid << ", wife "
        << wid << ", and children";
    for (int j = 0; j < numC; j++)
        cout << " " << cid[j];
    cout << ".\n";
}

void famTree::check()
{
    int numErrors = 0;
    for (int i = 1; i < MAX_NODE; i++)
    {
        if (people[i].m != 0)
        {
            if (people[i].m != fams[people[i].m].w || people[i].m != fams[people[i].m].h)
            {
                cout << "Individual " << i << " points to marriage family " << people[i].m
                    << " but there is no backpointer\n";
                numErrors += 1;
            }
        }
        if (people[i].p != 0)
        {
            bool isLinked = false;
            for (int j = 0; i < fams[people[i].p].numChildren; j++)
            {
                if (people[i].p == fams[people[i].p].c[j])
                    isLinked = true;
            }
            if (isLinked == false)
            {
                cout << "Individual " << i << " points to parent family " << people[i].p
                    << " but there is no backpointer\n";
            }
        }
    }
}