Author: William Zrnchik
Contents: 
    Makefile
    parser.c // given
    parser.h // given
    README.txt // this file
    run-tests // given
    shell.c // main implementation of shell
    shell.h // given
Running:
    Use make command to make all object files and executable function
Implementation Notes:
    Used multiple functions to make shell work for cleaner implementation
Limitations:
    Fails 2 tests
References:
    Jared Gibson helped with implementation ideas. ideas on what functions should be implemented